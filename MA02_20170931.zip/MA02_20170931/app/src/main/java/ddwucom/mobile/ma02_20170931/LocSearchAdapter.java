package ddwucom.mobile.ma02_20170931;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class LocSearchAdapter extends BaseAdapter {
    public static final String TAG = "LocSearchAdapter";

    private LayoutInflater inflater;
    private Context context;
    private int layout;
    private ArrayList<LocSearchDTO> list;

    public LocSearchAdapter(Context context, int resource, ArrayList<LocSearchDTO> list){
        this.context = context;
        this.layout = resource;
        this.list = list;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @Override
    public int getCount() {
        return list.size();
    }


    @Override
    public LocSearchDTO getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return list.get(position).get_id();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Log.d(TAG, "getView with position : " + position);
        View view = convertView;
        ViewHolder viewHolder = null;

        if (view == null) {
            view = inflater.inflate(layout, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.title = view.findViewById(R.id.title);
            viewHolder.link = view.findViewById(R.id.link);
            viewHolder.description = view.findViewById(R.id.description);

            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder)view.getTag();
        }

        LocSearchDTO dto = list.get(position);

        viewHolder.title.setText(dto.getTitle());
        viewHolder.link.setText(dto.getLink());
        viewHolder.description.setText(dto.getDescription());


        return view;
    }


    public void setList(ArrayList<LocSearchDTO> list) {
        this.list = list;
    }


    //    ※ findViewById() 호출 감소를 위해 필수로 사용할 것
    static class ViewHolder {
        public TextView title = null;
        public TextView link = null;
        public TextView description = null;


    }


}

