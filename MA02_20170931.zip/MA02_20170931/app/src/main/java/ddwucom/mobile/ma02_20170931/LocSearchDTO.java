package ddwucom.mobile.ma02_20170931;

import java.io.Serializable;

public class LocSearchDTO implements Serializable {

    private int _id;
    private String title;
    private String link;
    private String description;

    public LocSearchDTO() { }

    public int get_id(){ return _id; }
    public void set_id(int _id){ this._id = _id; }

    public String getTitle(){return title;}
    public void setTitle(String title){this.title = title;}

    public String getLink(){return link;}
    public void setLink(String link){this.link = link;}

    public String getDescription(){return description;}
    public void setDescription(String description){this.description = description;}

}
